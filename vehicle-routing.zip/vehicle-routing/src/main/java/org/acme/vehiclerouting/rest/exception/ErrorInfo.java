package org.acme.vehiclerouting.rest.exception;

public record ErrorInfo(String jobId, String message) {
}
