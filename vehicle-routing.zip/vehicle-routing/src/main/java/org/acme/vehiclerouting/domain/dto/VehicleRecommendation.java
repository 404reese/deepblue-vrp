package org.acme.vehiclerouting.domain.dto;

public record VehicleRecommendation(String vehicleId, int index) {
}
