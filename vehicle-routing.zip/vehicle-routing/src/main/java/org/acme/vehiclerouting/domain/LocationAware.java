package org.acme.vehiclerouting.domain;

public interface LocationAware {

    Location getLocation();
}
